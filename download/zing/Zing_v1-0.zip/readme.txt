Zing installer

After installing the game on your computer, if you are having any audio problems
run oalinst.exe to install the OpenAL library files.

If you are running on WinXp, install the patch found in the WinXP-Patch directory